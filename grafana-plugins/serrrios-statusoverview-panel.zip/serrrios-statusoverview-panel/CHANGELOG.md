# Changelog

## [v0.0.4] (dev-release)

Released at 17-06-2023

### Added

- Selecting metrics by regular expression
- Replacing the name of the metric by regular expression

### Changed

- Changed error display for duplicate metrics

### Fixed

- Small fixes

## [v0.0.3] (dev-release)

Released at 11-05-2023

* Initial release.